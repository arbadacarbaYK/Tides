(function () {
	'use strict';

	importScripts('lib/nostr-tools.js');
	importScripts('background.js');

	/**
	 * @file background-wrapper.js
	 * @description Service worker wrapper that imports required dependencies
	 * Loads nostr-tools and background script in the correct order
	 */

})();
